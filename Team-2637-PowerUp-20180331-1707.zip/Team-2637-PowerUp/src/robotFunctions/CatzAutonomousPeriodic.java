/*******************************************************
 *  Author : Jean Kwon
 *   Last Revised : 2-19-2018 JK
 *  Last revision summary: add the header
 *  Methods: runAutonomousPeriodic
 *  Functionality: suppress warnings
*******************************************************/

package robotFunctions;


public class CatzAutonomousPeriodic
{
	public static void runAutonomousPeriodic()
	{

	}
}
